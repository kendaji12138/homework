package examples;

import com.turkcelltech.jac.*;

public class MiddleType extends TaggedTypeExample
{
	public
	MiddleType(String name)
	{
		super(name);
	}
	
	public
	MiddleType()
	{
		super();
	}
	
}
